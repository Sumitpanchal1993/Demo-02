import React from 'react'

export default function Leftsidebar() {
  return (
    <>
      <ul>
        <li><a href="/">123</a></li>
        <li>ABC</li>
        <li>ABC</li>
        <li>ABC</li>
        <li>ABC</li>
        <li>ABC</li>
        <li>ABC</li>
        <li>ABC</li>
        <li>ABC</li>
      </ul>
    </>
  )
  }