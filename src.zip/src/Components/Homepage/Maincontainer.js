import React from 'react'


export default function Maincontainer() {
    return (
        <>
            <div className="container">
                <div className="cards">
                    Card 11
                </div>
                <div className="cards">
                    Card 12
                </div>
                <div className="cards">
                    Card 13
                </div>
            </div>
            <div className="container">
                <div className="cards">
                    Card 21
                </div>
                <div className="cards">
                    Card 22
                </div>
                <div className="cards">
                    Card 23
                </div>
            </div>
            <div className="container">
                <div className="cards">
                    Card 31
                </div>
                <div className="cards">
                    Card 32
                </div>
                <div className="cards">
                    Card 33
                </div>
            </div>
        </>
    )
}
