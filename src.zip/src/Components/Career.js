import React, { Component } from 'react'

export default class Career extends Component {
  render() {
    return (
      <h1>This is career Page</h1>
    )
  }
}