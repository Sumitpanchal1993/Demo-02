import React, { Component } from 'react'
import Maincontainer from './Homepage/Maincontainer'

export default class Products extends Component {
  render() {
    return (
      <>
      <h1>This is Products Page</h1>
      <Maincontainer/>
      </>
    )
  }
}