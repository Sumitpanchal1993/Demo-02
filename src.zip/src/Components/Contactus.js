import React, { Component } from 'react'
export default class Contactus extends Component {
  render() {
    return (
      <>
      <h1>This is the contact us page</h1>
      </>
    )
  }
}
