import React, { Component } from 'react'

export default class Customers extends Component {
  render() {
    return (
      <>
      <h1>This is Customer Page</h1>
      </>
    )
  }
}