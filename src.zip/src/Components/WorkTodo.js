import React, { Component } from 'react'
import '../Components/WorkTodo.css'

export default class WorkTodo extends Component {
  render() {
    return (
      <>
      <div className='base'>
        <h1 className='title'>This is a Todo Page</h1>
        <div className="mb-3, title">
          <label for="exampleFormControlInput1" className="form-label">Title of Work</label>
          <input type="email" className="form-control" id="exampleFormControlInput1" placeholder="Brief Detail"/>
        </div>
        <div className="mb-3, title">
          <label for="exampleFormControlTextarea1" className="form-label">Details of Work</label>
          <textarea className="form-control" id="exampleFormControlTextarea1" rows="5"></textarea>
        </div>
        <div> <button className='btn btn-primary'> Submit</button></div>
        </div>
      </>
    )
  }
}
