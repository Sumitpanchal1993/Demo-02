import React, { Component } from 'react'

export default class WorkDone extends Component {
  render() {
    return (
      <>
      <h1>This is Work Done Page</h1>
      </>
    )
  }
}
